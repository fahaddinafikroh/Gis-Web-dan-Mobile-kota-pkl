package com.example.uas_mobile_gis;

import androidx.appcompat.app.AppCompatActivity;

import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.TextView;

public class MainPeta extends AppCompatActivity {
    WebView webView;
    TextView tvKembali;
    int lebar;
    int tinggi;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_peta);
        webView = findViewById(R.id.webview);
        tvKembali = (TextView) findViewById(R.id.tvKembali);
        tvKembali.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
    }
    @Override
    public void onWindowFocusChanged(boolean hasFocus){
        //TODO Auto-generated method stub
        super.onWindowFocusChanged(hasFocus);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
        lebar = (webView.getWidth()/3);
        tinggi = webView.getHeight()/3;
        viewWeb();
    }
    public void viewWeb(){
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        webView.getSettings().setJavaScriptEnabled(true);
        webView.loadUrl("http://192.168.43.139:8090/geoserver/Pekalongan/wms?service=WMS&version=1.1.0" +
                "&request=GetMap&layers=Pekalongan:Grup%20Pekalongan&styles=&bbox=109.64214100130624,-6.93717050552368," +
                "109.7145559988603," +
                "-6.851726001054033&width="+lebar+"&height="+tinggi+"&srs=EPSG:4326&format=application/openlayers");
    }
}