package com.example.uas_mobile_gis;

public class Data {
    String id;
    String nama;
    String alamat;
    String kategori;
    String lat;
    String lng;

    public Data(String vid, String vnama,String vkategori, String valamat, String vlat, String vlng ){
        this.id=vid;
        this.nama=vnama;
        this.alamat=valamat;
        this.kategori=vkategori;
        this.lat=vlat;
        this.lng=vlng;
    }
}
