package com.example.uas_mobile_gis;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class MainActivity extends AppCompatActivity {
    public static final String URL = "http://192.168.43.194:8080/gis2/UAS/UAS_VISUAL/";
    ImageButton imgbtnLogin;
    EditText etEmail, etPassword;
    TextView tvRegister;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportActionBar().hide();

        tvRegister = (TextView) findViewById(R.id.tvRegister);
        tvRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this,MainActivityRegister.class);
                startActivity(intent);
                finish();
            }
        });

        etEmail=(EditText) findViewById(R.id.etEmail);
        etPassword=(EditText) findViewById(R.id.etPassword);

        imgbtnLogin=(ImageButton) findViewById(R.id.imgbtnLogin);
        imgbtnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                prosesLogin(etEmail.getText().toString(),etPassword.getText().toString());
            }
        });
    }
    public boolean isEmailValid(String email){
        boolean isValid = false;

        String expression = "^[\\w\\.-]+@([\\w\\-]+\\.)+[A-Z]{2,4}$";
        CharSequence inputStr = email;

        Pattern pattern = Pattern.compile(expression, Pattern.CASE_INSENSITIVE);
        Matcher matcher = pattern.matcher(inputStr);
        if (matcher.matches()){
            isValid = true;
        }
        return isValid;
    }

    void prosesLogin(String vemail, String vpassword){
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(URL)
                .addConverterFactory(GsonConverterFactory.create())
                .build();
        RegisterAPI api = retrofit.create(RegisterAPI.class);
        if (!isEmailValid(etEmail.getText().toString())){
            AlertDialog.Builder msg = new AlertDialog.Builder(MainActivity.this);

            msg.setMessage("Email Tidak Valid").setNegativeButton("Retry",null).create().show();
            return;
        }
        api.login(vemail, vpassword).enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                try {
                    JSONObject json = new JSONObject(response.body().string());

                    //cek apakah user ditemukan atau tidak
                    if (json.getString("result").toString().equals("1")) {
                        //cek status aktif atau tidak

                        Toast.makeText(MainActivity.this, "Login Berhasil",
                                Toast.LENGTH_SHORT).show();

                        Intent intent = new Intent(MainActivity.this, MainActivityHome.class);
                        intent.putExtra("nama", json.getJSONObject("data").getString("nama"));
                        intent.putExtra("email", json.getJSONObject("data").getString("email"));
                        startActivity(intent);
                        finish();

                    } else {
                        AlertDialog.Builder msg = new AlertDialog.Builder(MainActivity.this);
                        msg.setMessage("Email atau Password Salah")
                                .setNegativeButton("retry", null)
                                .create().show();
                    }
                } catch (JSONException | IOException e) {
                    e.printStackTrace();
                }
            }
            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {
                Log.i("Info Load","Load Gagal "+t.toString());
            }
        });
    }
}