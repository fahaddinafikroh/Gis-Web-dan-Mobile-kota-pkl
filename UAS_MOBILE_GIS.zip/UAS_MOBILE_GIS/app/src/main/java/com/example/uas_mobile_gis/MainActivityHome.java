package com.example.uas_mobile_gis;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;

public class MainActivityHome extends AppCompatActivity {
    TextView tvwelcome;
    ImageButton imgbtnLogut, imgbtnPeta, imgbtnInformasi, imgbtnTambah;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_home);
        getSupportActionBar().hide();
        tvwelcome = (TextView) findViewById(R.id.tvProfile_welcome);
        tvwelcome.setText("Welcome : "+getIntent().getStringExtra("nama")+
                "("+getIntent().getStringExtra("email")+")");
        imgbtnLogut = (ImageButton) findViewById(R.id.imgbtnLogut);
        imgbtnLogut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivityHome.this,MainActivity.class);
                startActivity(intent);
                finish();
            }
        });

        imgbtnPeta = (ImageButton) findViewById(R.id.imgbtnPeta);
        imgbtnPeta.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivityHome.this, MainPeta.class);
                intent.putExtra("nama",getIntent().getStringExtra("nama"));
                startActivity(intent);
            }
        });
        imgbtnInformasi = (ImageButton) findViewById(R.id.imgbtnInformasi);
        imgbtnInformasi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivityHome.this, MainDataFaskes.class);
                intent.putExtra("nama",getIntent().getStringExtra("nama"));
                startActivity(intent);
            }
        });
        imgbtnTambah = (ImageButton) findViewById(R.id.imgbtnTambah);
        imgbtnTambah.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivityHome.this, MainActivityTambah.class);
                intent.putExtra("nama",getIntent().getStringExtra("nama"));
                intent.putExtra("email",getIntent().getStringExtra("email"));
                startActivity(intent);
            }
        });
    }
}