package com.example.uas_mobile_gis;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import androidx.annotation.RequiresApi;

import android.Manifest;
import android.location.Location;
import android.location.LocationManager;
import android.os.Build;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import org.jetbrains.annotations.NotNull;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.FormBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;


public class MainActivityTambah extends AppCompatActivity {
    AksesGPS gps;
    Location loc;
    LocationManager lokasi;

    TextView tvKembali1;
    EditText etLat, etLng, etNama, etKategori, etAlamat;
    ImageButton btSimpan;

    OkHttpClient.Builder builder = new OkHttpClient.Builder();

    @RequiresApi(api = Build.VERSION_CODES.M)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_tambah);
        getSupportActionBar().hide();

        tvKembali1 = (TextView) findViewById(R.id.tvKembali1);
        tvKembali1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
        String[] permision=new String[]{Manifest.permission.ACCESS_FINE_LOCATION};
        this.requestPermissions(permision,0);


        etLat = (EditText) findViewById(R.id.setLat);
        etLng = findViewById(R.id.etLong);
        etNama = findViewById(R.id.etNama);
        etKategori = findViewById(R.id.etKategori);
        etAlamat = findViewById(R.id.etAlamat);


        try {
            gps = new AksesGPS(getApplicationContext());
            loc = gps.ambilLokasi();
            etLat.setText(""+loc.getLongitude());
            etLng.setText(""+loc.getLatitude());
        }catch (Exception e){
            Toast.makeText(MainActivityTambah.this,e.toString(),Toast.LENGTH_LONG).show();
        }


        builder.connectTimeout(20, TimeUnit.SECONDS);
        builder.writeTimeout(20,TimeUnit.SECONDS);
        builder.readTimeout(10,TimeUnit.SECONDS);

        btSimpan =(ImageButton) findViewById(R.id.btSimpan);
        btSimpan.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                simpan();
                kosong();

            }

        });
    }

    void kosong(){
        etNama.setText("");
        etAlamat.setText("");
        etKategori.setText("");
        etLat.setText("");
        etLng.setText("");
        etKategori.requestFocus();

    }

    void simpan(){
        OkHttpClient client = builder.build();

        RequestBody reqbody = new FormBody.Builder()
                .add("nama",etNama.getText().toString())
                .add("alamat",etAlamat.getText().toString())
                .add("kategori",etKategori.getText().toString())
                .add("lat",etLat.getText().toString())
                .add("lng",etLng.getText().toString())
                .build();

        Request request = new Request.Builder()
                .url("http://192.168.43.139/lil/faskes.php")
                .post(reqbody)
                .addHeader("connection","Keep-Alive")
                .addHeader("connection-type","Application/x-www-urlencoded")
                .build();
        Log.i("Info Kirim ","Proses Simpan Dijalankan");
        client.newCall(request).enqueue(new Callback() {

            @Override
            public void onFailure(@NotNull Call call, @NotNull IOException e) {
                Log.e("Err Kirim",e.toString());
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        Toast.makeText(MainActivityTambah.this,"Pengiriman Gagal",
                                Toast.LENGTH_LONG).show();
                    }
                });
            }

            @Override
            public void onResponse(@NotNull Call call, @NotNull Response response) throws IOException {
                Log.i("Info Kirim",response.message());
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        Toast.makeText(MainActivityTambah.this,"Pengiriman Berhasil",
                                Toast.LENGTH_LONG).show();
                    }
                });

            }
        });
    }
}
