<?php
//Ini untuk koneksi saja
include "koneksi.php";
//Akhir koneksi

//Pertama ambil data kiriman dari form
//$gid = $_POST['gid'];
$id = $_POST['id'];
$nama = $_POST['nama'];
$alamat = $_POST['alamat'];
$kategori=$_POST['kategori'];
$lat = $_POST['lat'];
$lng = $_POST['lng'];

//Kemudian dapat langsung kita simpan dengan query INSERT
$sql = pg_query ($conn,"INSERT INTO kesehatan (id,kategori,nama,alamat,geom) VALUES ('$id', '$kategori', '$nama', '$alamat', ST_SetSRID(ST_Makepoint($lng, $lat),4326))");
if(!$sql) {
 echo "Data gagal disimpan";
 } else {
    header("Location: hapus_kategori.php");
}
?>