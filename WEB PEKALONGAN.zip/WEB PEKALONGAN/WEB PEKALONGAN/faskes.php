<?php

include "koneksi.php";

$nama = $_POST['nama'];
$alamat = $_POST['alamat'];
$kategori = $_POST['kategori'];
$lat = $_POST['lat'];
$lng = $_POST['lng'];

$sql = "select max(id) as id from kesehatan";
$hasil = pg_query($conn, $sql);
$data = pg_fetch_array($hasil);
$id = $data['id'] + 1;

$sql = "insert into kesehatan (id, nama, alamat, kategori, geom) values ('$id','$nama', '$alamat','$kategori',ST_SetSRID(ST_MakePoint($lng,$lat), 4326))";

pg_query($conn, $sql);