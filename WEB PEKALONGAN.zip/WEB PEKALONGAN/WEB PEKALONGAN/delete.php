<?php
    include"koneksi.php";
    $id=$_REQUEST['id'];
    echo $id;
    $sql="delete from kesehatan where id='$id'";
   // DELETE FROM titik_objek WHERE id = '".$_GET['id']."'
    // $sql = mysqli_query($conn, "delete from kesehatan where id = '" . $_GET['id'] . "'");
    $hasil=pg_query($conn,$sql);
    if($hasil){
        header('location:hapus_kategori.php');
    }else {
        echo "Hapus data mahasiswa gagal, error :".pg_error($conn);
    }
?>