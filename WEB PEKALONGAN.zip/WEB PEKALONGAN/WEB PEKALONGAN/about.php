<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>Tentang</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="Free Website Template" name="keywords">
    <meta content="Free Website Template" name="description">

    <!-- Favicon -->
    <link href="img/favicon.ico" rel="icon">

    <!-- Google Font -->
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@200;400&family=Roboto:wght@400;500;700&display=swap" rel="stylesheet"> 

    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
    <link href="lib/tempusdominus/css/tempusdominus-bootstrap-4.min.css" rel="stylesheet" />

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/style.min.css" rel="stylesheet">
</head>

<body>
    
    <!-- Navbar Start -->
    <div class="container-fluid p-0 nav-bar">
        <nav class="navbar navbar-expand-lg bg-none navbar-dark py-3">
            <a href="index.php" class="navbar-brand px-lg-4 m-0">
                <h1 class="m-0 display-4 text-uppercase text-white">Kota Pekalongan</h1>
            </a>
            <button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#navbarCollapse">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse justify-content-between" id="navbarCollapse">
                <div class="navbar-nav ml-auto p-4">
                    <a href="index.php" class="nav-item nav-link active">Halaman Utama</a>
                    <a href="about.php" class="nav-item nav-link">Tentang</a>
                    <div class="nav-item dropdown">
                        <a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown">Peta</a>
                        <div class="dropdown-menu text-capitalize">
                            <a href="peta_kategori.php" class="dropdown-item">Sebaran Objek Faskes</a>
                        </div>
                    </div>
                    <div class="nav-item dropdown">
                        <a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown">Data</a>
                        <div class="dropdown-menu text-capitalize">
                            <a href="data_kategori.php" class="dropdown-item">Data Sebaran Objek Faskes</a>
                        </div>
                    </div>
                    <a href="index_login.php" class="nav-item nav-link">Edit Data</a>
                    <a href="contact.php" class="nav-item nav-link">Kontak</a>
                </div>
            </div>
        </nav>
    </div>
    <!-- Navbar End -->
    <!-- Page Header Start -->
    <div class="container-fluid page-header mb-5 position-relative overlay-bottom">
        <div class="d-flex flex-column align-items-center justify-content-center pt-0 pt-lg-5" style="min-height: 400px">
            <h1 class="display-4 mb-3 mt-0 mt-lg-5 text-white text-uppercase">Tentang</h1>
            <div class="d-inline-flex mb-lg-5">
                <p class="m-0 text-white"><a class="text-white" href="index.php">Halaman Utama</a></p>
                <p class="m-0 text-white px-2">/</p>
                <p class="m-0 text-white"><a class="text-white" href="about.php">Tentang</a></p>
            </div>
        </div>
    </div>
    <!-- Page Header End -->


    <!-- About Start -->
    <div class="container-fluid py-5">
        <div class="container">
            <div class="section-title">
                <h4 class="text-primary text-uppercase" style="letter-spacing: 5px;">Tentang</h4>
                <h1 class="display-4">Kota Pekalongan</h1>
            </div>
            <div class="row">
                <div class="col-lg-4 py-0 py-lg-5">
                    <h1 class="mb-3">Sejarah Singkat</h1>
                    <h5 class="mb-3">Kota Pekalongan adalah salah satu kota di pesisir pantai utara Provinsi Jawa Tengah. Kota ini berbatasan dengan laut jawa di utara, 
                        Kabupaten Pekalongan di sebelah selatan dan barat dan Kabupaten Batang di timur. Kota Pekalongan terdiri atas 4 kecamatan, yakni Pekalongan Utara, 
                        Pekalongan Barat, Pekalongan Selatan dan Pekalongan Timur. Kota Pekalongan terletak di jalur pantai Utara Jawa yang menghubungkan Jakarta-Semarang-Surabaya. 
                        Kota Pekalongan berjarak 384 km di timur Jakarta dan 101 km sebelah barat Semarang. Kota Pekalongan mendapat julukan kota batik. Hal ini tidak terlepas dari sejarah
                        bahwa sejak puluhan dan ratusan tahun lampau hingga sekarang, sebagian besar proses produksi batik Pekalongan dikerjakan di rumah-rumah. Akibatnya batik Pekalongan
                        menyatu erat dengan kehidupan masyarakat Pekalongan. Batik telah menjadi nafas penghidupan masyarakat Pekalongan dan terbukti tetap dapat eksis dan tidak menyerah 
                        pada perkembangan jaman, sekaligus menunjukkan keuletan dan keluwesan masyarakatnya untuk mengadopsi pemikiran-pemikiran baru.</p>
                  
                </div>
                <div class="col-lg-4 py-5 py-lg-0" style="min-height: 500px;">
                    <div class="position-relative h-100">
                        <img class="position-absolute w-100 h-170" src="img/logo.png" style="object-fit: cover;">
                    </div>
                </div>
                <div class="col-lg-4 py-0 py-lg-5">
                    <h1 class="mb-3">Visi dan Misi</h1>
                    <p>VISI :<br> TERWUJUDNYA KOTA PEKALONGAN YANG LEBIH SEJAHTERA, MANDIRI DAN BERBUDAYA BERLANDASKAN NILIA-NILAI RELIGIUSITAS.</p><br>
                    <p>MISI :<br>
                        <br>1. Meningkatkan akses dan mutu pendidikan masyarakat Kota Pekalongan.
                        <br>2. Meningkatkan kualitas pelayanan publik untuk sebesar-besarnya kesejahteraan masyarakat,
                        <br>3. Memberdayakan ekonomi rakyat berbasis potensi lokal berdasarkan prinsip pembangunan yang berkelanjutan.
                        <br>4.  Meningkatkan kualitas dan kuantitas sarana dan prasaranaperkotaan yang ramah lingkungan.
                        <br>5. Mengembangkan IT berbasis komunitas.
                        <br>6. Melestarikan budaya dan kearifan bermasyarakat yang berakhlaqul karimah.</p>
                   
                </div>
            </div>
        </div>
    </div>
    <!-- About End -->


    <!-- Footer Start -->
    <div class="container-fluid footer text-white mt-5 pt-5 px-0 position-relative overlay-top">
        <div class="row mx-0 pt-5 px-sm-3 px-lg-5 mt-4">
            <div class="col-lg-3 col-md-6 mb-5">
                <h4 class="text-white text-uppercase mb-4" style="letter-spacing: 3px;">Get In Touch</h4>
                <p><i class="fa fa-map-marker-alt mr-2"></i>Jalan Jatayu No.4, <br>Kota Pekalongan 51114</p>
                <p><i class="fa fa-phone-alt mr-2"></i> (0285) 421972</p>
                <p class="m-0"><i class="fa fa-envelope mr-2"></i>dinkes_ktpekalongan@yahoo.com/ dinkes@pekalongankota.go.id</p>
            </div>
            <div class="col-lg-3 col-md-6 mb-5">
                <h4 class="text-white text-uppercase mb-4" style="letter-spacing: 3px;">Follow Kita</h4>
                <div class="d-flex justify-content-start">
                    <a class="btn btn-lg btn-outline-light btn-lg-square mr-2" href="https://twitter.com/pkl_dinkes" ><i class="fab fa-twitter"></i></a>
                    <a class="btn btn-lg btn-outline-light btn-lg-square mr-2" href="https://www.facebook.com/dinkeskotapekalongan"><i class="fab fa-facebook-f"></i></a>
                    <a class="btn btn-lg btn-outline-light btn-lg-square mr-2" href="https://www.instagram.com/dinkeskotapekalongan" ><i class="fab fa-instagram"></i></a>
                    <a class="btn btn-lg btn-outline-light btn-lg-square" href="https://www.youtube.com/channel/UC2EuEe7x_lENBgv4h6y71ww" class="fa fa-youtube-play" ><i class="ui-youtube"></i></a>
                </div>
            </div>
            <div class="col-lg-2 col-md-6">
                <aside class="widget widget_nav_menu">
                    <h4 class="widget-title text-white" >Link Terkait</h4>
                    <ul>
                        <li><a href="http://depkes.go.id">Kemenkes RI</a></li>
                        <li><a href="https://rsudbendan.pekalongankota.go.id/">RSUD Bendan</a></li>
                        <li><a href="https://yankes.kemkes.go.id/app/siranap/">SIRANAP</a></li>
                        <li><a href="https://dinkes.pekalongankota.go.id/halaman/daftar-media-sosial-puskesmas-kota-pekalongan.html">Puskesmas Kota Pekalongan</a></li>
                        <li><a href="http://dinkesjatengprov.go.id/">Dinkes Provinsi Jateng</a></li>
                        <li><a href="http://aspak.yankes.kemkes.go.id/aplikasi/">ASPAK</a></li>
                        <li><a href="http://pekalongankota.go.id">Pemeritah Kota Pekalongan</a></li>                        
                    </ul>
                </aside>
            </div>
            <div class="col-lg-4 col-md-6">
                <aside class="widget widget-popular-posts">
                    <h4 class="widget-title text-white">Berita Terbaru</h4>
                    <ul class="post-list-small">                            
                                                    <li class="post-list-small__item">
                            <article class="post-list-small__entry clearfix">
                                <div class="post-list-small__img-holder">
                                    <div class="thumb-container thumb-100">
                                        <a href="https://dinkes.pekalongankota.go.id/berita/pembekalan-deteksi-dini-ppok-bagi-petugas-kesehatan-di-kota-pekalongan-.html">
                                            <img widt="100" height="100" data-src="https://dinkes.pekalongankota.go.id/upload/berita/berita_20220914111702.jpeg" src="https://dinkes.pekalongankota.go.id/upload/berita/berita_20220914111702.jpeg" alt="" class="post-list-small__img--rounded lazyloaded">
                                        </a>
                                    </div>
                                </div>
                                <div class="post-list-small__body">
                                    <h3 class="post-list-small__entry-title">
                                        <a href="https://dinkes.pekalongankota.go.id/berita/pembekalan-deteksi-dini-ppok-bagi-petugas-kesehatan-di-kota-pekalongan-.html">Pembekalan Deteksi Dini PPOK bagi Petugas Kesehatan di Kota Pekalongan </a>
                                    </h3>
                                    <ul class="entry__meta">
                                        <li class="entry__meta-date">
                                            14 September 2022 [11:16:30]                                            </li>
                                    </ul>
                                </div>                  
                            </article>
                        </li>
                                                    <li class="post-list-small__item">
                            <article class="post-list-small__entry clearfix">
                                <div class="post-list-small__img-holder">
                                    <div class="thumb-container thumb-100">
                                        <a href="https://dinkes.pekalongankota.go.id/berita/peningkatan-kapasitas-petugas-dalam-implementasi-stbm-dan-persiapan-menuju-odf-kota-pekalongan.html">
                                            <img widt="100" height="100" data-src="https://dinkes.pekalongankota.go.id/upload/berita/berita_20220914105820.jpeg" src="https://dinkes.pekalongankota.go.id/upload/berita/berita_20220914105820.jpeg" alt="" class="post-list-small__img--rounded lazyloaded">
                                        </a>
                                    </div>
                                </div>
                                <div class="post-list-small__body">
                                    <h3 class="post-list-small__entry-title">
                                        <a href="https://dinkes.pekalongankota.go.id/berita/peningkatan-kapasitas-petugas-dalam-implementasi-stbm-dan-persiapan-menuju-odf-kota-pekalongan.html">Peningkatan Kapasitas Petugas dalam Implementasi STBM dan Persiapan menuju ODF Kota Pekalongan</a>
                                    </h3>
                                    <ul class="entry__meta">
                                        <li class="entry__meta-date">
                                            14 September 2022 [10:57:45]                                            </li>
                                    </ul>
                                </div>                  
                            </article>
                        </li>
                                                    
                    </ul>
                </aside>
            </div>
        </div>
        <div class="container-fluid text-center text-white border-top mt-4 py-4 px-sm-3 px-md-5" style="border-color: rgba(256, 256, 256, .1) !important;">
            <p class="mb-2 text-white">Copyright &copy; <a class="font-weight-bold" >A22.2021.02859</a>| Fahaddina Fikroh</a></p>
            <p class="m-0 text-white">Pemograman Gis <a class="font-weight-bold" href="https://htmlcodex.com"> </a></p>
        </div>
    </div>
    <!-- Footer End -->


    <!-- Back to Top -->
    <a href="#" class="btn btn-lg btn-primary btn-lg-square back-to-top"><i class="fa fa-angle-double-up"></i></a>


    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.bundle.min.js"></script>
    <script src="lib/easing/easing.min.js"></script>
    <script src="lib/waypoints/waypoints.min.js"></script>
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>
    <script src="lib/tempusdominus/js/moment.min.js"></script>
    <script src="lib/tempusdominus/js/moment-timezone.min.js"></script>
    <script src="lib/tempusdominus/js/tempusdominus-bootstrap-4.min.js"></script>

    <!-- Contact Javascript File -->
    <script src="mail/jqBootstrapValidation.min.js"></script>
    <script src="mail/contact.js"></script>

    <!-- Template Javascript -->
    <script src="js/main.js"></script>
</body>

</html>