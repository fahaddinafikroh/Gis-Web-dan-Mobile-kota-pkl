var wms_layers = [];

var format_ADM_Kec_Pekalongan_0 = new ol.format.GeoJSON();
var features_ADM_Kec_Pekalongan_0 = format_ADM_Kec_Pekalongan_0.readFeatures(json_ADM_Kec_Pekalongan_0, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_ADM_Kec_Pekalongan_0 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_ADM_Kec_Pekalongan_0.addFeatures(features_ADM_Kec_Pekalongan_0);
var lyr_ADM_Kec_Pekalongan_0 = new ol.layer.Vector({
                declutter: true,
                source:jsonSource_ADM_Kec_Pekalongan_0, 
                style: style_ADM_Kec_Pekalongan_0,
                interactive: true,
    title: 'ADM_Kec_Pekalongan<br />\
    <img src="styles/legend/ADM_Kec_Pekalongan_0_0.png" /> 0 - 1437<br />\
    <img src="styles/legend/ADM_Kec_Pekalongan_0_1.png" /> 1437 - 1513<br />\
    <img src="styles/legend/ADM_Kec_Pekalongan_0_2.png" /> 1513 - 1589<br />\
    <img src="styles/legend/ADM_Kec_Pekalongan_0_3.png" /> 1590 - 1666<br />\
    <img src="styles/legend/ADM_Kec_Pekalongan_0_4.png" /> 1666 - 4000<br />'
        });

lyr_ADM_Kec_Pekalongan_0.setVisible(true);
var layersList = [lyr_ADM_Kec_Pekalongan_0];
lyr_ADM_Kec_Pekalongan_0.set('fieldAliases', {'KECAMATAN': 'KECAMATAN', 'KOTA': 'KOTA', 'PROVINSI': 'PROVINSI', 'KODE_DAGRI': 'KODE_DAGRI', 'jml': 'jml', });
lyr_ADM_Kec_Pekalongan_0.set('fieldImages', {'KECAMATAN': 'TextEdit', 'KOTA': 'TextEdit', 'PROVINSI': 'TextEdit', 'KODE_DAGRI': 'Range', 'jml': 'Range', });
lyr_ADM_Kec_Pekalongan_0.set('fieldLabels', {'KECAMATAN': 'inline label', 'KOTA': 'inline label', 'PROVINSI': 'inline label', 'KODE_DAGRI': 'inline label', 'jml': 'inline label', });
lyr_ADM_Kec_Pekalongan_0.on('precompose', function(evt) {
    evt.context.globalCompositeOperation = 'normal';
});