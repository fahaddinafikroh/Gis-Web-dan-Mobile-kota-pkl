<?php
	$conn=pg_connect("host=localhost dbname=webgis user=postgres password=lia");
?>