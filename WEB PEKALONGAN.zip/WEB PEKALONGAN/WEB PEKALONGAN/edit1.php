<? 
include "koneksi.php";

$id=$_POST['txtid'];
$nama=$_POST['txtnama'];
$alamat=$_POST['txtalamat'];
$kategori=$_POST['txtkategori'];
$lat=$_POST['txtlat'];
$lng=$_POST['txtlng'];



$sql="UPDATE kesehatan SET kategori='$kategori',nama='$nama', alamat='$alamat', geom=ST_SetSRID(ST_MakePoint($lng,$lat), 4326) WHERE id='$id'";

$hasil=pg_query($conn,$sql);
if($hasil){
    header('location:edit_kategori.php');
}else{
    echo "<center> Data gagal diubah, error".pg_error($conn);
    echo "<hr><a href='edit_kategori.php'> kembali</a></center>";
}
?>