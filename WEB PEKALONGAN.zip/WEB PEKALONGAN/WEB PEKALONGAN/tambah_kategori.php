<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Halaman Admin</title>
<style>
ul {
  list-style-type: none;
  margin: 0;
  padding: 0;
  overflow: hidden;
  background-color: #ea9304;
}

li {
  float: left;
}

li a, .dropbtn {
  display: inline-block;
  color: black;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
}

li a:hover, .dropdown:hover .dropbtn {
  background-color: #fee5bc;
}

li.dropdown {
  display: inline-block;
}

.dropdown-content {
  display: none;
  position: absolute;
  background-color:  #ea9304;
  min-width: 160px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  z-index: 1;
}

.dropdown-content a {
  color: black;
  padding: 12px 16px;
  text-decoration: none;
  display: block;
  text-align: left;
}

.dropdown-content a:hover {background-color: whitesmoke;}

.dropdown:hover .dropdown-content {
  display: block;
}
body{
  background-color : #fee5bc;

}
</style>
</head>
<body>
<br>
<br>
<br>

<ul>
<li><a href="welcome.php">Dasboard</a></li>
  <li class="dropdown">
    <a href="javascript:void(0)" class="dropbtn">Edit Data</a>
    <div class="dropdown-content">
      <a href="edit_kategori.php">Edit Data Sebaran Objek Fasilitas Kesehatan</a>
    </div>
  </li>
  <li class="dropdown">
    <a href="javascript:void(0)" class="dropbtn">Hapus Data</a>
    <div class="dropdown-content">
      <a href="hapus_kategori.php">Hapus Data Sebaran Objek Fasilitas Kesehatan</a>
    </div>
  </li>
  <li class="dropdown">
    <a href="javascript:void(0)" class="dropbtn">Tambah Data</a>
    <div class="dropdown-content">

      <a href="tambah_kategori.php">Tambah Data Sebaran Objek Fasilitas Kesehatan</a>
    </div>
  </li>
  <li><a href="logout.php">Logout</a></li>
</ul>

</head>
<body>
  



<br>
<center><h1><font color="black"> Tambah Data Fasilitas Kesehatan Kota Pekalongan</font></h1></center>
 <form action="simpan.php" method="post" enctype="multipart/form-data" id="form1">
    <table width="700"  border="0">
        <tr>
            <td width="150" ><font color="black">ID</font></td>
            <td><input type="text" name="id" size="20" value="" ></td>
        </tr>
        <tr>
            <td width="150" ><font color="black">Nama</font></td>
            <td><input type="text" name="nama" size="40" value="" ></td>
        </tr>
        <tr>
            <td width="150" ><font color="black">Alamat</font></td>
            <td><input type="text" name="alamat" size="40" value="" ></td>
        </tr>
        <tr>
            <td width="150"><font color="black"> Kategori</td>
            <td>
                <select name="kategori" id="kategori" >
                    <option values="Rumah Sakit">Rumah Sakit</option>
                    <option values="Klinik">Klinik</option>
                    <option values="Puskesmas">Puskesmas</option>
                </select></font>
            </td>
        </tr>
        <tr>
            <td width="150" ><font color="black">Latitude</font></td>
            <td><input type="text" name="lat" size="40" value="" ></td>
        </tr>
        <tr>
            <td width="150" ><font color="black">Longitude</font></td>
            <td><input type="text" name="lng" size="40" value="" ></td>
        </tr>
        <tr>
            <td></td>
            <td><input name="simpan" type="submit" value="Simpan" class="tombol2"></td>
        </tr>
    </table>
</form>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<footer>
 <center> <p>A22.2021.02859 - Fahaddina Fikroh & A22.2021.02859 - Aprilia Hikari Tamira Jasmine<br> Pemograman Gis</p></center>
</footer>

</body>
</html>
