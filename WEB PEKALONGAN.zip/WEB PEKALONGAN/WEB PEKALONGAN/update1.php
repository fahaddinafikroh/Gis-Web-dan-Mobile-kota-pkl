<?php

session_start();

if (!isset($_SESSION['username'])) {
    header("Location: index.php");
}

?>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Halaman Admin</title>
<style>
ul {
  list-style-type: none;
  margin: 0;
  padding: 0;
  overflow: hidden;
  background-color: #ea9304;
}

li {
  float: left;
}

li a, .dropbtn {
  display: inline-block;
  color: black;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
}

li a:hover, .dropdown:hover .dropbtn {
  background-color: #fee5bc;
}

li.dropdown {
  display: inline-block;
}

.dropdown-content {
  display: none;
  position: absolute;
  background-color:  #ea9304;
  min-width: 160px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  z-index: 1;
}

.dropdown-content a {
  color: black;
  padding: 12px 16px;
  text-decoration: none;
  display: block;
  text-align: left;
}

.dropdown-content a:hover {background-color: whitesmoke;}

.dropdown:hover .dropdown-content {
  display: block;
}
body{
  background-color : #fee5bc;

}
</style>
</head>
<body>
<br>
<br>
<br>

<ul>
<li><a href="welcome.php">Dasboard</a></li>
  <li class="dropdown">
    <a href="javascript:void(0)" class="dropbtn">Edit Data</a>
    <div class="dropdown-content">
      <a href="edit_kategori.php">Edit Data Sebaran Objek Fasilitas Kesehatan</a>
    </div>
  </li>
  <li class="dropdown">
    <a href="javascript:void(0)" class="dropbtn">Hapus Data</a>
    <div class="dropdown-content">
      <a href="hapus_kategori.php">Hapus Data Sebaran Objek Fasilitas Kesehatan</a>
    </div>
  </li>
  <li class="dropdown">
    <a href="javascript:void(0)" class="dropbtn">Tambah Data</a>
    <div class="dropdown-content">

      <a href="tambah_kategori.php">Tambah Data Sebaran Objek Fasilitas Kesehatan</a>
    </div>
  </li>
  <li><a href="logout.php">Logout</a></li>
</ul>
<?
        include "koneksi.php";
        $id=$_GET['id'];
        $sql = "select id, nama, alamat, kategori, st_y(st_astext(st_GeometryN(geom, 1))),
        st_x(st_astext(st_GeometryN(geom, 1)))  from kesehatan where id='$id'";
       // $sql="SELECT id,kategori,nama,alamat,ST_X(geom) AS lng, ST_Y(geom) AS lat from kesehatan where id='$id'";
       // $sql="select * from kesehatan where id='$id'";
        $hasil=pg_query($conn,$sql);
        $data=pg_fetch_array($hasil);

        $id="";
        $nama="";
        $alamat="";
        $kategori="";
        $lat="";
        $lng="";
        $geom="";

        if($data){
            $id=$data['id'];
            $nama=$data['nama'];
            $alamat=$data['alamat'];
            $kategori=$data['kategori'];
            $lat = $data['st_y'];
            $lng = $data['st_x'];
        }
        ?>
        <h1><center>Peta Persebaran Fasilitas Kesehatan<br>Pada Kota Pekalongan Tahun 2020</center></h1>
        <br>
        <form method="post" action="edit1.php">
            <table border="0" width="600">
                <tr>
                    <td width="150" bgcolor="brown"><font color="white">Id</font></td>
                    <td><input type="text" name="txtid" size="3" value="<? echo $id; ?>" ></td>
                </tr>
                <tr>
                <td width="150" bgcolor="brown"><font color="white">Nama</font></td>
                    <td><input type="text" name="txtnama" size="30" value="<? echo $nama; ?>" ></td>
                </tr>
                <tr>
                <td width="150" bgcolor="brown"><font color="white">Alamat</font></td>
                    <td><input type="text" name="txtalamat" size="90" value="<? echo $alamat; ?>" ></td>
                </tr>
                <tr>
                    <td width="150" bgcolor="brown"><font color="white">Kategori 
                    </td><td>
                    <select name="txtkategori" id="kategori" >
                    <option value="Rumah Sakit">Rumah Sakit</option>
                    <option value="Klinik">Klinik</option>
                    <option value="Puskesmas">Puskesmas</option>
                    
                    </select></font></td>
                </tr>
                <tr>
                <td width="150" bgcolor="brown"><font color="white">Lat</font></td>
                    <td><input type="text" name="txtlat" size="10" value="<? echo $lat; ?>" ></td>
                </tr>
                <tr>
                <td width="150" bgcolor="brown"><font color="white">lng</font></td>
                    <td><input type="text" name="txtlng" size="10" value="<? echo $lng; ?>" ></td>
                </tr>
                      
                             
                <tr>
                    <td></td>
                    <td><a href= <? echo "data_kategori.php ?"?>; ><input type="submit" value="Ubah" style="width:100px;" ></a>

                    <input type="button" value="Kembali" style="width:100px;" onclick="history.back(-1)"></td>
                </tr>
            </table>

        </form>
        <footer>
 <center> <p>A22.2021.02859 - Fahaddina Fikroh & A22.2021.02884 - Aprilia Hikari Tamira Jasmine<br> Pemograman Gis</p></center>
</footer>

    
    </body>
</html>