<style type="text/css">
h2{
  font-family: sans-serif;
}
 
table {
  font-family: Arial, Helvetica, sans-serif;
  color: #666;
  text-shadow: 1px 1px 0px #fff;
  background: #eaebec;
  border: #ccc 1px solid;
}
 
table th {
  padding: 15px 35px;
  border-left:1px solid #e0e0e0;
  border-bottom: 1px solid #e0e0e0;
  background: #ededed;
}
 
table th:first-child{  
  border-left:none;  
}
 
table tr {
  text-align: center;
  padding-left: 20px;
}
 
table td:first-child {
  text-align: left;
  padding-left: 20px;
  border-left: 0;
}
 
table td {
  padding: 15px 30px;
  border-top: 1px solid #ffffff;
  border-bottom: 1px solid #e0e0e0;
  border-left: 1px solid #e0e0e0;
  background: #fafafa;
  background: -webkit-gradient(linear, left top, left bottom, from(#fbfbfb), to(#fafafa));
  background: -moz-linear-gradient(top, #fbfbfb, #fafafa);
}
 
table tr:last-child td {
  border-bottom: 0;
}
 
table tr:last-child td:first-child {
  -moz-border-radius-bottomleft: 3px;
  -webkit-border-bottom-left-radius: 3px;
  border-bottom-left-radius: 3px;
}
 
table tr:last-child td:last-child {
  -moz-border-radius-bottomright: 3px;
  -webkit-border-bottom-right-radius: 3px;
  border-bottom-right-radius: 3px;
}
 
table tr:hover td {
  background: #f2f2f2;
  background: -webkit-gradient(linear, left top, left bottom, from(#f2f2f2), to(#f0f0f0));
  background: -moz-linear-gradient(top, #f2f2f2, #f0f0f0);
}
</style>
<h2>Data Tempat Ibadah</h2>
<?php
    include "koneksi.php";
?>
<input type="button" value="Tambah Data" style="width:150px;" onclick="window.open('tambah_kategori.php','_self');">
<input type="button" value="Lihat peta" style="width:150px;" onclick="window.open('peta_kategori.php','_self');">
    <br>
    <br>
    <table border="1" cellpadding="1" cellspacing="0" >
    <thead>
    <tr>
        <th>ID</th>
        <th>Nama</th>
        <th>Alamat</th>
        <th>Kategori</th>
        <th>Lat</th>
        <th>Lng</th>
        <th>Hapus</th>
    </tr>
    </thead>
<?php
    $sql="select * from kesehatan order by id";
    $hasil=mysqli_query($conn,$sql);
    while($data=mysqli_fetch_array($hasil)) {
?>
    <tr>    
        <td><?php echo $data['id']; ?></td>
        <td><?php echo $data['nama']; ?></td>
        <td><?php echo $data['alamat']; ?></td>
        <td><?php echo $data['kategori']; ?></td>
        <td><?php echo $data['lat']; ?></td>
        <td><?php echo $data['lng']; ?></td>
        
        <td>
            <a href=<?php echo "delete.php?id=" .$data['id']; ?>>
            <img src="images/hapus.jpg" width="20" height="20">
            </a>
        </td>
        </tr>
<?php
    }
?>
    </table>