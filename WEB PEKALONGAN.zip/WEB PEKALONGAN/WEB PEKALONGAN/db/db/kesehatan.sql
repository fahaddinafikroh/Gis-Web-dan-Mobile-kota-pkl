-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 29, 2022 at 05:17 AM
-- Server version: 10.4.20-MariaDB
-- PHP Version: 8.0.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pemograman_gis`
--

-- --------------------------------------------------------

--
-- Table structure for table `kesehatan`
--

CREATE TABLE `kesehatan` (
  `id` int(11) NOT NULL,
  `nama` char(80) DEFAULT NULL,
  `alamat` char(200) DEFAULT NULL,
  `kategori` varchar(20) DEFAULT NULL,
  `lat` float DEFAULT NULL,
  `lng` float DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `kesehatan`
--

INSERT INTO `kesehatan` (`id`, `nama`, `alamat`, `kategori`, `lat`, `lng`) VALUES
(1, 'RSUD Bendan', 'Jl. Sriwijaya No.2, Bendan Kergon, Kec. Pekalongan Barat, Kota Pekalongan, Jawa Tengah 51119', 'Rumah Sakit', -6.891, 109.661),
(2, 'RS Budi Rahayu', 'Jl. Barito No.5, Padukuhan Kraton, Kec. Pekalongan Utara, Kota Pekalongan, Jawa Tengah 51146', 'Rumah Sakit', -6.88, 109.672),
(3, 'RS Siti Khadijah', 'Jl. Bandung No.39, Kauman, Kec. Pekalongan Timur, Kota Pekalongan, Jawa Tengah 51129', 'Rumah Sakit', -6.886, 109.676),
(4, 'RS Aro Pekalongan', 'Jl. Dr. Sutomo No.16, Gamer, Kec. Pekalongan Timur, Kota Pekalongan, Jawa Tengah 51123', 'Rumah Sakit', -6.903, 109.701),
(5, 'RS Karomah Holistik', 'Jl. Gajah Mada Barat No.124, Tirto, Kec. Pekalongan Barat, Kota Pekalongan, Jawa Tengah 51118', 'Rumah Sakit', -6.889, 109.652),
(6, 'RS Bhakti Waluyo', 'Jl. Dr. Sutomo No.32, Sokorejo, Kec. Pekalongan Tim., Kota Pekalongan, Jawa Tengah 51121', 'Rumah Sakit', -6.903, 109.692),
(7, 'RS HA Zaky Djunaid', 'Jl. Pelita II No.8, Pringrejo, Kec. Pekalongan Barat, Kota Pekalongan, Jawa Tengah 51117', 'Rumah Sakit', -6.911, 109.651),
(8, 'RS Anugerah', 'Jl. Perintis Kemerdekaan No.3, Pasirkratonkramat, Kec. Pekalongan Barat, Kota Pekalongan, Jawa Tengah 51145', 'Rumah Sakit', -6.887, 109.664),
(9, 'RS Hermina Pekalongan', 'Jl. Jenderal Sudirman No.16, Podosugih, Kec. Pekalongan Barat, Kota Pekalongan, Jawa Tengah 51112', 'Rumah Sakit', -6.898, 109.667),
(10, 'Puskesmas Bendan', 'Jl. Slamet No.2, Bendan, Kec. Pekalongan Bar., Kota Pekalongan, Jawa Tengah 51119', 'Puskesmas', -6.89, 109.666),
(11, 'Puskesmas Kramatsari', 'Jalan AMD No.1, Kramatsari, Kec. Pekalongan Bar., Kota Pekalongan, Jawa Tengah 51118', 'Puskesmas', -6.884, 109.66),
(12, 'Puskesmas Wonoprinngo', 'Blumbang, Pegaden Tengah, Kec. Wonopringgo, Kabupaten Pekalongan, Jawa Tengah 51181', 'Puskesmas', -6.92438, 109.668),
(13, 'Puskesmas Medono', 'Jl. Setia Bhakti No.99, Medono, Kec. Pekalongan Bar., Kota Pekalongan, Jawa Tengah 51111', 'Puskesmas', -6.904, 109.669),
(14, 'Klinik Pratama Aisyiyah Siti Aisyah', 'Jalan Dokter Wahidin No.3, Poncol, Kec. Pekalongan Tim., Kota Pekalongan, Jawa Tengah 51122', 'Klinik', -6.89, 109.68),
(15, 'Klinik Mutiara', ' Jl. Teratai No.96, Poncol, Kec. Pekalongan Tim., Kota Pekalongan, Jawa Tengah 51122', 'Klinik', -6.888, 109.681),
(16, 'Puskesmas Tondano', ' Jl. Tondano No.5A, RW.6, Poncol, Kec. Pekalongan Tim., Kota Pekalongan, Jawa Tengah 51122', 'Puskesmas', -6.894, 109.681),
(17, 'Puskesmas Klego', '4M8M+246, Klego, Kec. Pekalongan Tim., Kota Pekalongan, Jawa Tengah 51124', 'Puskesmas', -6.884, 109.682),
(18, 'Puskesmas Jenggot', 'Jl. Pelita III No.1A, RT.03/RW.05, Jenggot, Kec. Pekalongan Sel., Kota Pekalongan, Jawa Tengah 51133', 'Puskesmas', -6.917, 109.669),
(19, 'Klinik Umum Annesa Sehati', '4M76+CV4, Jl. Angkatan 66, Kramatsari, Kec. Pekalongan Bar., Kota Pekalongan, Jawa Tengah 51118', 'Klinik', -6.886, 109.662),
(20, 'Klinik Pratama Mitra Bahagia', 'Kertoharjo, Kec. Pekalongan Sel., Kota Pekalongan, Jawa Tengah 51171', 'Klinik', -6.92533, 109.684);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `kesehatan`
--
ALTER TABLE `kesehatan`
  ADD PRIMARY KEY (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
