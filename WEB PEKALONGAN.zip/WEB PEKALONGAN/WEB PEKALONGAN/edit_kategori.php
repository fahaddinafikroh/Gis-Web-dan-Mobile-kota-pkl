<?php

session_start();

if (!isset($_SESSION['username'])) {
    header("Location: index.php");
}

?>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Halaman Admin</title>
<style>
ul {
  list-style-type: none;
  margin: 0;
  padding: 0;
  overflow: hidden;
  background-color: #ea9304;
}

li {
  float: left;
}

li a, .dropbtn {
  display: inline-block;
  color: black;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
}

li a:hover, .dropdown:hover .dropbtn {
  background-color: #fee5bc;
}

li.dropdown {
  display: inline-block;
}

.dropdown-content {
  display: none;
  position: absolute;
  background-color:  #ea9304;
  min-width: 160px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  z-index: 1;
}

.dropdown-content a {
  color: black;
  padding: 12px 16px;
  text-decoration: none;
  display: block;
  text-align: left;
}

.dropdown-content a:hover {background-color: whitesmoke;}

.dropdown:hover .dropdown-content {
  display: block;
}
body{
  background-color : #fee5bc;

}
</style>
</head>
<body>
<br>
<br>
<br>

<ul>
<li><a href="welcome.php">Dasboard</a></li>
  <li class="dropdown">
    <a href="javascript:void(0)" class="dropbtn">Edit Data</a>
    <div class="dropdown-content">
      <a href="edit_kategori.php">Edit Data Sebaran Objek Fasilitas Kesehatan</a>
    </div>
  </li>
  <li class="dropdown">
    <a href="javascript:void(0)" class="dropbtn">Hapus Data</a>
    <div class="dropdown-content">
      <a href="hapus_kategori.php">Hapus Data Sebaran Objek Fasilitas Kesehatan</a>
    </div>
  </li>
  <li class="dropdown">
    <a href="javascript:void(0)" class="dropbtn">Tambah Data</a>
    <div class="dropdown-content">

      <a href="tambah_kategori.php">Tambah Data Sebaran Objek Fasilitas Kesehatan</a>
    </div>
  </li>
  <li><a href="logout.php">Logout</a></li>
</ul>



    <!-- Menu Start -->
    <center>
    <div class="container-fluid pt-5">
        <div class="container">
            <div class="section-title">
                <h1 class="text-primary text-uppercase" style="letter-spacing: 5px;"> Edit Data</h1>
                <h1 class="display-4">Peta Sebaran Fasilitas Kesehatan<br> Kota Pekalongan</h1><br>
                <?php 
    include "koneksi.php";
?>
</center>
    

    <center><table border="1" width="800">
        <tr style="background-color: brown;">
            <td><center>Id</td>
            <td><center>Nama</td>  
            <td><center>Alamat</td>
            <td><center>Kategori</td>
            <td><center>lat</td>
            <td><center>lng</td>
            <td><center>Setting</td>
            
        </tr>

        <?php
            $no = 1;
            $sql = "SELECT id,kategori,nama,alamat,ST_X(geom) AS lng, ST_Y(geom) AS lat from kesehatan order by id";
            $hasil = pg_query($conn,$sql);
            while($data=pg_fetch_array($hasil)){

                ?>
                    <tr>
                        <td><center><?php echo $data['id'] ?></td>
                        <td><center><?php echo $data['nama'] ?></td>
                        <td><center><?php echo $data['alamat'] ?></td>
                        <td><center><?php echo $data['kategori'] ?></td>
                        <td><center><?php echo $data['lat'] ?></td>
                        <td><center><?php echo $data['lng'] ?></td>
                        <td>
                            <a href=<? echo "update1.php?id=$data[id]"; ?>>
                            <center><img src="images/edit.png" width="15" height="15"></a> 
                        </td>
                    </tr>
        <?php
             }   
                  ?>
    </table>
            </div>
            
        </div>
    </div>
    <br>
    <br>
    <footer>
 <center> <p>A22.2021.02859 - Fahaddina Fikroh & A22.2021.02884 - Aprilia Hikari Tamira Jasmine<br> Pemograman Gis</p></center>
</footer>


    
    </body>
</html>